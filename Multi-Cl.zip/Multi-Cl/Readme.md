Put "EFST4CL.R" and "WT_assay_clinical.csv" under the same directory.
Need library(class).
Change the default directory to where the zip file unzipped.(setwd("..."))
And run the R script.
Results are printed in the terminal.
